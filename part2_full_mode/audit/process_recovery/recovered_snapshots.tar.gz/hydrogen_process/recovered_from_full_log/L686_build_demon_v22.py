"""Chrono-Bastion v2.2 FULL-mode Demon Dungeon builder & adversarial tester."""

import collections
import json
import time

import local_judge_v22 as judge
import hero_v22


def build_chrono_bastion() -> dict:
    g = judge.make_empty_grid()

    def put(x: int, y: int, t: str):
        assert 1 <= x <= 38 and 1 <= y <= 24, f"Out of inner bounds {(x, y)}"
        g[y][x] = t

    def rect_tw(x1: int, y1: int, x2: int, y2: int):
        for y in range(y1, y2 + 1):
            for x in range(x1, x2 + 1):
                put(x, y, "T_W")

    # 1. Central Vertical T_W Spine at x=17 (y=1..24 except doors at y=4, y=13, y=20)
    for y in range(1, 25):
        if y not in (4, 13, 20):
            put(17, y, "T_W")

    # K1 Airlock at (17..19, 4): P_GATE -> PIT -> R_GATE (unbombable; requires plates & gf=True & 1 jump)
    put(17, 4, "P_GATE")
    put(18, 4, "PIT")
    put(19, 4, "R_GATE")
    for px, py in ((18, 3), (18, 5), (19, 3), (19, 5)):
        put(px, py, "T_W")

    # 2. Horizontal Spine separating North-East (K1) and South-East (K2+V): y=11, x=18..38
    rect_tw(18, 11, 38, 11)

    # 3. Sniper SWITCH Bunker at (16, 13) (double flip False->True->False via THROW from West(13,13) or East(19,13))
    put(16, 13, "SWITCH")
    for px in range(14, 19):
        put(px, 12, "T_W")
        put(px, 14, "T_W")
    put(14, 13, "PIT")
    put(15, 13, "PIT")
    put(17, 13, "PIT")
    put(18, 13, "PIT")

    # 4. PIT_BRIDGE at (17..18, 20): 2-wide PIT moat flanked by T_W (100% unjumpable without BOX_2!)
    put(16, 20, "ONEWAY_R")
    put(17, 20, "PIT")
    put(18, 20, "PIT")
    put(18, 19, "T_W")
    put(18, 21, "T_W")

    # 5. West Arena Puzzles (x=1..16): 2 Coupled Boxes + 2 Plates + Dual-Laser Shield/Timing
    # Box 1 -> Plate 1 at (13, 3) with Sokoban corner walls + unbombable LASER_D(10,1)
    put(7, 6, "BOX")
    put(13, 3, "PLATE")
    # Unbombable LASER_D(10,1) against border y=0
    put(10, 1, "LASER_D")
    put(10, 2, "PIT")
    put(9, 1, "T_W")
    put(9, 2, "T_W")
    put(11, 1, "T_W")
    put(11, 2, "T_W")
    # Inner Sokoban blocks (cheap W where bombing doesn't bypass any outer lock, plus T_W shelf around PLATE_1)
    put(12, 2, "T_W")
    put(14, 2, "T_W")
    put(14, 3, "T_W")
    put(6, 4, "W")
    put(7, 4, "W")
    put(8, 4, "W")
    put(12, 6, "W")
    put(13, 6, "W")

    # Box 2 -> Plate 2 at (12, 20), later pushed East through ONEWAY_R(16,20) into PIT(17,20)!
    put(7, 20, "BOX")
    put(12, 20, "PLATE")
    # Unbombable LASER_R(4, 20) + LASER2_U(10, 24) crossing at (10, 20)!
    put(4, 20, "LASER_R")
    put(5, 20, "PIT")
    put(4, 19, "T_W")
    put(5, 19, "T_W")
    put(4, 21, "T_W")
    put(5, 21, "T_W")

    put(10, 24, "LASER2_U")
    put(10, 23, "PIT")
    put(9, 23, "T_W")
    put(9, 24, "T_W")
    put(11, 23, "T_W")
    put(11, 24, "T_W")

    # One-way Return Portal 1B -> (6, 16) -> ONEWAY_R(7, 16) walled in
    put(6, 16, "PORTAL_1B")
    put(7, 16, "ONEWAY_R")
    put(5, 16, "T_W")
    put(6, 15, "T_W")
    put(7, 15, "T_W")
    put(6, 17, "T_W")
    put(7, 17, "T_W")

    # Decoy MIMIC & TNT in West corner
    put(4, 3, "MIMIC")
    put(14, 8, "TNT")

    # 6. North-East K1 Vault (x=18..38, y=1..10)
    # After (19,4)=R_GATE: slide ICE across %12 crossfire (LASER_D(29,1) + LASER2_L(38,4)), grab K1(33,8), exit PORTAL_1A(35,8)
    put(23, 4, "CRACK")
    put(24, 4, "CRACK")
    put(27, 4, "ICE")
    put(28, 4, "ICE")

    put(29, 1, "LASER_D")
    put(29, 2, "PIT")
    put(28, 1, "T_W")
    put(28, 2, "T_W")
    put(30, 1, "T_W")
    put(30, 2, "T_W")

    put(38, 4, "LASER2_L")
    put(37, 4, "PIT")
    put(37, 3, "T_W")
    put(38, 3, "T_W")
    put(37, 5, "T_W")
    put(38, 5, "T_W")

    put(33, 8, "K1")
    put(35, 8, "PORTAL_1A")
    # Force portal exit direction "R" by putting T_W top/bottom/right of PORTAL_1A!
    put(35, 7, "T_W")
    put(35, 9, "T_W")
    put(36, 8, "T_W")

    # 7. South-East K2 + V Citadel (x=19..38, y=12..24)
    # Spine at x=22 (y=12..24 minus y=16), gating K2 behind PIT(22,16) + B_GATE(23,16) -> requires THROW_L from (19,13)!
    for y in range(12, 25):
        if y != 16:
            put(22, y, "T_W")
    put(22, 16, "PIT")
    put(23, 16, "B_GATE")
    put(23, 15, "T_W")
    put(23, 17, "T_W")

    # Inside K2 Room: LASER_D(28, 12) + LASER2_R(24, 22) meeting at K2(28, 22) -> PORTAL_2A(30, 22)
    put(28, 12, "LASER_D")
    put(28, 13, "PIT")
    put(27, 12, "T_W")
    put(27, 13, "T_W")
    put(29, 12, "T_W")
    put(29, 13, "T_W")

    put(24, 22, "LASER2_R")
    put(25, 22, "PIT")
    put(24, 21, "T_W")
    put(25, 21, "T_W")
    put(24, 23, "T_W")
    put(25, 23, "T_W")

    put(28, 21, "ICE")
    put(28, 22, "K2")
    put(30, 22, "PORTAL_2A")
    # Put ONEWAY_R on (29, 22) so hero enters K2/PORTAL cleanly rightwards
    put(29, 22, "ONEWAY_R")

    # 8. Final V Vault [33..38, 12..17]: sealed by x=32 (y=12..16), y=17 (x=33..38)
    for y in range(12, 17):
        put(32, y, "T_W")
    rect_tw(33, 17, 38, 17)
    put(33, 14, "PORTAL_2B")
    put(34, 14, "ONEWAY_R")
    put(36, 14, "V")
    put(35, 14, "CRACK")

    # Compute exact metrics + check hero_v22 solver to obtain verified author_solution!
    dec = judge.decode_grid_only(g)
    print(f"Budget: {dec['spent_gold']}G / {judge.MAX_BUDGET}G | T_W inner: {dec['counts']['T_W']} / 120")

    eng = judge.GameEngineV22(dec)
    t0 = time.perf_counter()
    # Give solver ample time to synthesize clean optimal author path!
    plan = hero_v22.solve_full_plan(eng.get_state(1), time_budget=15.0)
    dt = time.perf_counter() - t0
    for a in plan:
        eng.step(a)
        if eng.status != "ALIVE":
            break
    print(f"hero_v22 15s plan: status={eng.status} turns={eng.turn} hp={eng.hp} k={(eng.has_k1, eng.has_k2)} time={dt:.2f}s")

    dungeon = {
        "taunt": "Plates feed pits, switches flip twice, mod-12 waits for none.",
        "grid": g,
        "author_solution": plan,
    }
    return dungeon


if __name__ == "__main__":
    d = build_chrono_bastion()
    ok, msg = judge.validate_dungeon(d, check_spawn_4turn=True, check_author=True)
    print("validate_dungeon:", ok, msg)
    if ok:
        # Also test with 1.45s live Turn-1 budget using decide_action!
        eng = judge.GameEngineV22(judge.decode_grid_only(d["grid"]))
        mem = {}
        t1 = None
        max_t2 = 0.0
        for turn in range(1, judge.MAX_TURNS + 1):
            st = eng.get_state(turn)
            ts = time.perf_counter()
            act = hero_v22.decide_action(st, mem)
            el = (time.perf_counter() - ts) * 1000.0
            if turn == 1:
                t1 = el
            else:
                max_t2 = max(max_t2, el)
            eng.step(act)
            if eng.status != "ALIVE":
                break
        hs, ds = eng.compute_scores()
        print(f"Live 1.45s hero_v22 vs Bastion: {eng.status} t={eng.turn} hp={eng.hp} k={(eng.has_k1, eng.has_k2)} hero={hs:.1f} demon={ds:.1f} t1={t1:.1f}ms max_t2={max_t2:.2f}ms")
