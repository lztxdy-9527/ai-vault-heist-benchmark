"""
《阴间地牢：金库攻防战》 下半场 v2.2 (FULL 全图明牌) 参赛提交 — DeepSeek V4.1 Flash 1017

  魔王侧 `build_dungeon()`：v2.2 三连硬机关（PLATE/P_GATE + LASER2 双频 12 拍 + ONEWAY）重构的
      "金库三重门" 逻辑迷宫；1..200 步作者自证；出生 4 回合零伤准入。
  勇者侧 `decide_action()`：FULL 明牌下的时间展开分层规划器
      （阶段 Dijkstra 求路 + 推箱 Sokoban 子规划 + 逐拍前向校验），
      Turn 1 用 1.60s 全局规划，Turn>=2 用 0.42s 增量复核/重规划。

设计要点（与题目要求逐条对应）：
  1. 只用一份文件同时实现造图与破阵；
  2. 决策侧完全基于 `state` 快照（`mode=="FULL"` 全图可见），不依赖任何跨局全局变量，
     进程被重建（memory 清空）时 Turn>1 也能在 0.42s 内重新规划或安全降级；
  3. 规划结果每一步都用内置前向引擎复演校验，校验不过立即重规划，绝不盲走。
"""

import heapq
import time

GRID_W = 40
GRID_H = 26
CELLS = GRID_W * GRID_H
MAX_TURNS = 240
MAX_AUTHOR_STEPS = 200
SPAWN = (2, 13)

DIRV = {"U": (0, -1), "D": (0, 1), "L": (-1, 0), "R": (1, 0)}
DIR_OF = {(0, -1): "U", (0, 1): "D", (-1, 0): "L", (1, 0): "R"}
DIR_KEYS = ("U", "D", "L", "R")
MOVE_ACT = {"U": "MOVE_U", "D": "MOVE_D", "L": "MOVE_L", "R": "MOVE_R"}
JUMP_ACT = {"U": "JUMP_U", "D": "JUMP_D", "L": "JUMP_L", "R": "JUMP_R"}
THROW_ACT = {"U": "THROW_U", "D": "THROW_D", "L": "THROW_L", "R": "THROW_R"}

VALID_ACTIONS = frozenset((
    "MOVE_U", "MOVE_D", "MOVE_L", "MOVE_R", "WAIT",
    "JUMP_U", "JUMP_D", "JUMP_L", "JUMP_R",
    "THROW_U", "THROW_D", "THROW_L", "THROW_R", "BOMB",
))

HIGH_WALL = frozenset(("W", "T_W",
                       "LASER_U", "LASER_D", "LASER_L", "LASER_R",
                       "LASER2_U", "LASER2_D", "LASER2_L", "LASER2_R"))
LASER_TILES = {"LASER_U": "U", "LASER_D": "D", "LASER_L": "L", "LASER_R": "R"}
LASER2_TILES = {"LASER2_U": "U", "LASER2_D": "D", "LASER2_L": "L", "LASER2_R": "R"}
MIRROR_FOLD = {
    "MIRROR_NE": {"L": "U", "R": "U", "U": "R", "D": "R"},
    "MIRROR_SE": {"L": "D", "R": "D", "U": "R", "D": "R"},
    "MIRROR_SW": {"L": "D", "R": "D", "U": "L", "D": "L"},
    "MIRROR_NW": {"L": "U", "R": "U", "U": "L", "D": "L"},
}
SPRING_DIR = {"SPRING_U": "U", "SPRING_D": "D", "SPRING_L": "L", "SPRING_R": "R"}
ONEWAY_DIR = {"ONEWAY_U": "U", "ONEWAY_D": "D", "ONEWAY_L": "L", "ONEWAY_R": "R"}
PORTAL_PAIR = {"PORTAL_1A": "PORTAL_1B", "PORTAL_1B": "PORTAL_1A",
               "PORTAL_2A": "PORTAL_2B", "PORTAL_2B": "PORTAL_2A"}
PORTALS = frozenset(PORTAL_PAIR)
BLAST_IMMUNE = frozenset(("T_W", "K1", "K2", "V", "PIT",
                          "PORTAL_1A", "PORTAL_1B", "PORTAL_2A", "PORTAL_2B",
                          "PLATE", "P_GATE",
                          "ONEWAY_U", "ONEWAY_D", "ONEWAY_L", "ONEWAY_R"))
BLAST_WIPE = frozenset(("W", "ICE", "SWITCH", "R_GATE", "B_GATE", "HEAL", "MIMIC",
                        "MIRROR_NE", "MIRROR_SE", "MIRROR_SW", "MIRROR_NW",
                        "SPRING_U", "SPRING_D", "SPRING_L", "SPRING_R",
                        "LASER_U", "LASER_D", "LASER_L", "LASER_R",
                        "LASER2_U", "LASER2_D", "LASER2_L", "LASER2_R"))


# =============================================================================
# 一、前向仿真内核（逐字复刻 v2.2 物理，供计划校验 / 战斗推演）
# =============================================================================

class _Sim(object):
    """单局前向仿真：只需要 terrain / occupant / hero / gates / bombs。"""

    __slots__ = ("ter", "occ", "hx", "hy", "hp", "keys", "jumps", "throws",
                 "bombs", "gates", "dmg", "status", "exposed", "tnt_armed")

    def __init__(self, ter, occ, hero, gates):
        self.ter = [row[:] for row in ter]
        self.occ = [row[:] for row in occ]
        self.hx = hero[0]
        self.hy = hero[1]
        self.hp = hero[2]
        self.keys = [bool(hero[3]), bool(hero[4])]
        self.jumps = hero[5]
        self.throws = hero[6]
        self.bombs = hero[7]
        self.gates = bool(gates)
        self.dmg = 0.0
        self.status = None
        self.exposed = set()
        self.tnt_armed = set()

    # ---- 查询 ----
    def inside(self, x, y):
        return 0 <= x < GRID_W and 0 <= y < GRID_H

    def plates_active(self):
        found = False
        for y in range(1, GRID_H - 1):
            row = self.ter[y]
            for x in range(1, GRID_W - 1):
                if row[x] == "PLATE":
                    found = True
                    if self.occ[y][x] != "BOX":
                        return False
        return found

    def high_wall(self, x, y):
        t = self.ter[y][x]
        if t in HIGH_WALL:
            return True
        if t == "R_GATE":
            return not self.gates
        if t == "B_GATE":
            return self.gates
        if t == "P_GATE":
            return not self.plates_active()
        return False

    def blocks_oneway(self, x, y, dirv):
        d = ONEWAY_DIR.get(self.ter[y][x])
        if d is None:
            return False
        return dirv != DIRV[d]

    def _trap(self, amt):
        self.dmg += min(self.hp, amt)
        self.hp -= amt

    def _can_enter(self, x, y, dirv, kind):
        if not self.inside(x, y):
            return False
        if self.high_wall(x, y):
            return False
        o = self.occ[y][x]
        if o == "BOX" or o == "TNT":
            return False
        if kind == "BOX":
            if (x, y) == (self.hx, self.hy):
                return False
            if self.ter[y][x] in ("K1", "K2", "V"):
                return False
        if self.blocks_oneway(x, y, dirv):
            return False
        return True

    # ---- 8 步原子位移 ----
    def _move_entity(self, kind, p0, p1, dirv):
        steps = 0
        portal_count = 0
        suppress = False
        stop_momentum = False
        while True:
            steps += 1
            if self.ter[p0[1]][p0[0]] == "CRACK":
                self.ter[p0[1]][p0[0]] = "PIT"
            if kind == "BOX":
                self.occ[p0[1]][p0[0]] = None
                self.occ[p1[1]][p1[0]] = "BOX"
            else:
                self.hx, self.hy = p1
                self.exposed.add(p1)
            t1 = self.ter[p1[1]][p1[0]]
            if kind == "BOX":
                if t1 == "PIT":
                    self.occ[p1[1]][p1[0]] = None
                    self.ter[p1[1]][p1[0]] = "EMPTY"
                    stop_momentum = True
                elif t1 == "MIMIC":
                    self.ter[p1[1]][p1[0]] = "EMPTY"
                elif t1 == "SWITCH":
                    self.gates = not self.gates
            else:
                if t1 == "PIT":
                    self._trap(100)
                elif t1 == "MIMIC":
                    self._trap(45)
                    self.ter[p1[1]][p1[0]] = "EMPTY"
                    stop_momentum = True
                elif t1 == "HEAL":
                    self.hp = min(100, self.hp + 30)
                    self.ter[p1[1]][p1[0]] = "EMPTY"
                elif t1 == "SWITCH":
                    self.gates = not self.gates
            if kind != "BOX" and self.hp <= 0:
                self.status = "DEAD"
                return True
            if kind != "BOX":
                if t1 == "K1":
                    self.keys[0] = True
                    self.ter[p1[1]][p1[0]] = "EMPTY"
                elif t1 == "K2":
                    self.keys[1] = True
                    self.ter[p1[1]][p1[0]] = "EMPTY"
                elif t1 == "V" and self.keys[0] and self.keys[1] and self.hp > 0:
                    self.status = "CLEARED"
                    return True
            if steps >= 32 or stop_momentum:
                break
            t1 = self.ter[p1[1]][p1[0]]
            nxt = None
            newdir = dirv
            if t1 == "ICE":
                nxt = (p1[0] + dirv[0], p1[1] + dirv[1])
                if not self._can_enter(nxt[0], nxt[1], dirv, kind):
                    nxt = None
            elif t1 in MIRROR_FOLD:
                newdir = DIRV[MIRROR_FOLD[t1][DIR_OF[dirv]]]
                nxt = (p1[0] + newdir[0], p1[1] + newdir[1])
                if not self._can_enter(nxt[0], nxt[1], newdir, kind):
                    nxt = None
            elif t1 in SPRING_DIR:
                sd = DIRV[SPRING_DIR[t1]]
                newdir = sd
                land = (p1[0] + 3 * sd[0], p1[1] + 3 * sd[1])
                if not self.inside(land[0], land[1]):
                    land = None
                for k in (1, 2, 3):
                    px, py = p1[0] + k * sd[0], p1[1] + k * sd[1]
                    blocked = (not self.inside(px, py)) or self.high_wall(px, py) or \
                        self.occ[py][px] in ("BOX", "TNT") or self.blocks_oneway(px, py, sd)
                    if kind == "BOX" and self.inside(px, py):
                        if (px, py) == (self.hx, self.hy) or self.ter[py][px] in ("K1", "K2", "V"):
                            blocked = True
                    if blocked:
                        if kind == "BOX" and self.inside(px, py) and self.occ[py][px] == "TNT":
                            self.tnt_armed.add((px, py))
                        land = (p1[0] + (k - 1) * sd[0], p1[1] + (k - 1) * sd[1]) if k >= 2 else None
                        break
                nxt = land
            elif t1 in PORTALS and not suppress:
                other = PORTAL_PAIR[t1]
                pp = None
                for yy in range(GRID_H):
                    for xx in range(GRID_W):
                        if self.ter[yy][xx] == other:
                            pp = (xx, yy)
                            break
                    if pp:
                        break
                ok = pp is not None and self.occ[pp[1]][pp[0]] is None
                if kind == "BOX" and ok and pp == (self.hx, self.hy):
                    ok = False
                if ok:
                    portal_count += 1
                    nxt = pp
                    suppress = True
                else:
                    nxt = None
            elif t1 in PORTALS and suppress:
                suppress = False
                if portal_count >= 2:
                    nxt = None
                else:
                    fx, fy = p1[0] + dirv[0], p1[1] + dirv[1]
                    nxt = (fx, fy) if self._can_enter(fx, fy, dirv, kind) else None
            if nxt is None:
                break
            p0, p1 = p1, nxt
            dirv = newdir
        return False

    # ---- 爆炸 ----
    def _explode(self, sources):
        q = []
        seen = set()
        for s in sources:
            if s not in seen:
                seen.add(s)
                q.append(s)
        all_src = []
        while q:
            s = q.pop()
            all_src.append(s)
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    cx, cy = s[0] + dx, s[1] + dy
                    if not self.inside(cx, cy) or (cx, cy) in seen:
                        continue
                    if self.occ[cy][cx] == "TNT" or (cx, cy) in self.bombs:
                        seen.add((cx, cy))
                        q.append((cx, cy))
        a = b = 0
        for (sx, sy) in all_src:
            if abs(sx - self.hx) <= 1 and abs(sy - self.hy) <= 1:
                if self.occ[sy][sx] == "TNT":
                    a += 60
                elif (sx, sy) in self.bombs:
                    b += 50
        if a + b > 0:
            self.dmg += min(self.hp, a + b) * (a / float(a + b))
            self.hp -= (a + b)
        for (sx, sy) in all_src:
            if self.occ[sy][sx] == "TNT":
                self.occ[sy][sx] = None
            self.bombs.pop((sx, sy), None)
        union = set()
        for (sx, sy) in all_src:
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    cx, cy = sx + dx, sy + dy
                    if self.inside(cx, cy):
                        union.add((cx, cy))
        for (cx, cy) in union:
            if self.occ[cy][cx] == "BOX":
                self.occ[cy][cx] = None
            t = self.ter[cy][cx]
            if t in BLAST_IMMUNE:
                continue
            if t == "CRACK":
                self.ter[cy][cx] = "PIT"
            elif t in BLAST_WIPE:
                self.ter[cy][cx] = "EMPTY"
        for (cx, cy) in union:
            if self.occ[cy][cx] == "BOX" and self.ter[cy][cx] == "PIT":
                self.occ[cy][cx] = None
                self.ter[cy][cx] = "EMPTY"
        if self.hp > 0 and self.ter[self.hy][self.hx] == "PIT":
            self._trap(100)
        if self.hp <= 0:
            self.status = "DEAD"

    def _rays(self, red, blue):
        out = []
        armed = set()
        for y in range(GRID_H):
            for x in range(GRID_W):
                t = self.ter[y][x]
                if t in LASER_TILES:
                    if not red:
                        continue
                    d = LASER_TILES[t]
                elif t in LASER2_TILES:
                    if not blue:
                        continue
                    d = LASER2_TILES[t]
                else:
                    continue
                dx, dy = DIRV[d]
                cells = []
                for step in range(1, 11):
                    nx, ny = x + dx * step, y + dy * step
                    if not self.inside(nx, ny):
                        break
                    if self.high_wall(nx, ny) or self.occ[ny][nx] == "BOX":
                        break
                    if self.occ[ny][nx] == "TNT":
                        armed.add((nx, ny))
                        break
                    cells.append((nx, ny))
                out.append(cells)
        return out, armed

    def _throw(self, sx, sy, dirv):
        rng = 6
        sp = 0
        while rng > 0:
            nx, ny = sx + dirv[0], sy + dirv[1]
            if not self.inside(nx, ny):
                return
            rng -= 1
            sx, sy = nx, ny
            if self.high_wall(nx, ny) or self.occ[ny][nx] == "BOX":
                return
            if self.occ[ny][nx] == "TNT":
                self.tnt_armed.add((nx, ny))
                return
            t = self.ter[ny][nx]
            if t == "SWITCH":
                self.gates = not self.gates
                return
            if t == "MIMIC":
                self.ter[ny][nx] = "EMPTY"
                return
            if t in MIRROR_FOLD:
                dirv = DIRV[MIRROR_FOLD[t][DIR_OF[dirv]]]
                continue
            if t in PORTALS and sp < 2:
                continue
        t = self.ter[sy][sx]
        if t != "ICE" and t not in MIRROR_FOLD:
            return
        for _ in range(32):
            nx, ny = sx + dirv[0], sy + dirv[1]
            if not self.inside(nx, ny):
                return
            sx, sy = nx, ny
            if self.high_wall(nx, ny) or self.occ[ny][nx] == "BOX":
                return
            if self.occ[ny][nx] == "TNT":
                self.tnt_armed.add((nx, ny))
                return
            t = self.ter[ny][nx]
            if t == "SWITCH":
                self.gates = not self.gates
                return
            if t == "MIMIC":
                self.ter[ny][nx] = "EMPTY"
                return
            if t in MIRROR_FOLD:
                dirv = DIRV[MIRROR_FOLD[t][DIR_OF[dirv]]]
                continue
            if t == "ICE":
                continue
            return

    # ---- 单回合 ----
    def apply(self, action):
        if self.status is not None:
            return self.status
        self.turn = getattr(self, "turn", 0) + 1
        self.exposed = {(self.hx, self.hy)}
        self.tnt_armed = set()
        hx, hy = self.hx, self.hy
        if action == "BOMB":
            if self.bombs > 0 and (hx, hy) not in self.bombs:
                self.bombs -= 1
                self.bombs_map[(hx, hy)] = 3
        elif action.startswith("MOVE_"):
            d = action[5]
            dx, dy = DIRV[d]
            p1 = (hx + dx, hy + dy)
            if not self.inside(*p1) or self.high_wall(*p1) or self.occ[p1[1]][p1[0]] == "TNT":
                pass
            elif self.occ[p1[1]][p1[0]] == "BOX":
                if not self.blocks_oneway(p1[0], p1[1], (dx, dy)):
                    p2 = (hx + 2 * dx, hy + 2 * dy)
                    if self._can_enter(p2[0], p2[1], (dx, dy), "BOX"):
                        self._move_entity("BOX", p1, p2, (dx, dy))
                        if self.status is None and \
                                self._can_enter(p1[0], p1[1], (dx, dy), "HERO"):
                            self._move_entity("HERO", (hx, hy), p1, (dx, dy))
            elif not self.blocks_oneway(p1[0], p1[1], (dx, dy)):
                self._move_entity("HERO", (hx, hy), p1, (dx, dy))
        elif action.startswith("JUMP_"):
            if self.jumps > 0:
                self.jumps -= 1
                d = action[5]
                dx, dy = DIRV[d]
                p1 = (hx + dx, hy + dy)
                p2 = (hx + 2 * dx, hy + 2 * dy)
                bad = (not self.inside(*p1)) or self.high_wall(*p1) or \
                    self.blocks_oneway(p1[0], p1[1], (dx, dy))
                if not bad:
                    if (not self.inside(*p2)) or self.high_wall(*p2) or \
                            self.occ[p2[1]][p2[0]] in ("BOX", "TNT") or \
                            self.blocks_oneway(p2[0], p2[1], (dx, dy)):
                        bad = True
                if not bad:
                    self._move_entity("HERO", (hx, hy), p2, (dx, dy))
        elif action.startswith("THROW_"):
            if self.throws > 0:
                self.throws -= 1
                self._throw(hx, hy, DIRV[action[6]])
        if self.status is None:
            for k in list(self.bombs_map.keys()):
                self.bombs_map[k] -= 1
            srcs = [p for p, t in self.bombs_map.items() if t <= 0] + list(self.tnt_armed)
            if srcs:
                self._explode(srcs)
        if self.status is None:
            t = getattr(self, "turn", 0)
            red = (t % 3 == 0)
            blue = (t % 4 == 0)
            if red or blue:
                rays, armed = self._rays(red, blue)
                m = 0
                for cells in rays:
                    for c in cells:
                        if c in self.exposed:
                            m += 1
                            break
                if m:
                    self.dmg += min(self.hp, 50 * m)
                    self.hp -= 50 * m
                    if self.hp <= 0:
                        self.status = "DEAD"
                if self.status is None and armed:
                    self._explode(list(armed))
        if self.status is None and getattr(self, "turn", 0) >= MAX_TURNS:
            self.status = "TIMEOUT"
        return self.status


# =============================================================================
# 二、静态地图分析 / 时间展开求路
# =============================================================================

class _World(object):
    """从 FULL 观测快照提取的静态世界：地形、实体、机关位置、激光周期表。"""

    __slots__ = ("ter", "occ", "hero", "gates", "plates", "pgate", "boxes",
                 "cannons", "targets", "switch_cells", "pit_cells", "tnt_cells",
                 "clues", "turn", "hazard")

    def __init__(self, state):
        self.ter = []
        self.occ = []
        clues = state.get("clues") or [[False] * GRID_W for _ in range(GRID_H)]
        for y in range(GRID_H):
            trow = state["terrain"][y]
            orow = state["occupant"][y]
            trow2 = []
            for x in range(GRID_W):
                t = trow[x]
                if t == "CHEST":
                    t = "MIMIC" if clues[y][x] else "HEAL"
                trow2.append(t)
            self.ter.append(trow2)
            self.occ.append([orow[x] for x in range(GRID_W)])
        h = state["hero"]
        self.hero = (int(h["x"]), int(h["y"]), int(h["hp"]), bool(h["keys"][0]),
                     bool(h["keys"][1]), int(h["jumps"]), int(h["throws"]), int(h["bombs"]))
        self.gates = bool(state["gates_flipped"])
        self.turn = int(state["turn"])
        self.plates = []
        self.pgate = []
        self.boxes = []
        self.cannons = []
        self.switch_cells = []
        self.pit_cells = []
        self.tnt_cells = []
        for y in range(GRID_H):
            for x in range(GRID_W):
                t = self.ter[y][x]
                if t == "PLATE":
                    self.plates.append((x, y))
                elif t == "P_GATE":
                    self.pgate.append((x, y))
                elif t in LASER_TILES:
                    self.cannons.append((x, y, LASER_TILES[t], 3))
                elif t in LASER2_TILES:
                    self.cannons.append((x, y, LASER2_TILES[t], 4))
                elif t == "SWITCH":
                    self.switch_cells.append((x, y))
                elif t == "PIT":
                    self.pit_cells.append((x, y))
                elif t == "TNT":
                    self.tnt_cells.append((x, y))
                if self.occ[y][x] == "BOX":
                    self.boxes.append((x, y))
        self.targets = state.get("targets") or {}
        self.hazard = [[0] * GRID_W for _ in range(GRID_H)]
        self._build_hazard()

    def _build_hazard(self):
        """每个格子按 turn%12 的激光命中门数（含 P_GATE 关闭态）。"""
        active = self.plates_active()
        for (cx, cy, d, period) in self.cannons:
            dx, dy = DIRV[d]
            for step in range(1, 11):
                nx, ny = cx + dx * step, cy + dy * step
                if not (0 <= nx < GRID_W and 0 <= ny < GRID_H):
                    break
                t = self.ter[ny][nx]
                if t in HIGH_WALL or self.occ[ny][nx] == "BOX":
                    break
                if t == "R_GATE" and not self.gates:
                    break
                if t == "B_GATE" and self.gates:
                    break
                if t == "P_GATE" and not active:
                    break
                if self.occ[ny][nx] == "TNT":
                    break
                for p in (range(3, 12, 3) if period == 3 else range(4, 12, 4)):
                    self.hazard[ny][nx] |= (1 << p)

    def plates_active(self):
        if not self.plates:
            return False
        for (x, y) in self.plates:
            if self.occ[y][x] != "BOX":
                return False
        return True

    def high_wall(self, x, y):
        if not (0 <= x < GRID_W and 0 <= y < GRID_H):
            return True
        t = self.ter[y][x]
        if t in HIGH_WALL:
            return True
        if t == "R_GATE":
            return not self.gates
        if t == "B_GATE":
            return self.gates
        if t == "P_GATE":
            return not self.plates_active()
        return False

    def blocks_oneway(self, x, y, dirv):
        d = ONEWAY_DIR.get(self.ter[y][x])
        return d is not None and dirv != DIRV[d]


def _sim_hero_move(ter, occ, gates, hx, hy, d, kind_dir=None):
    """在静态地形上模拟一次 MOVE，返回 (end, dmg, flip, exposed, moved)。"""
    dx, dy = DIRV[d]
    p0 = (hx, hy)
    p1 = (hx + dx, hy + dy)
    ex = [p1]

    def hw(x, y):
        if not (0 <= x < GRID_W and 0 <= y < GRID_H):
            return True
        t = ter[y][x]
        if t in HIGH_WALL:
            return True
        if t == "R_GATE":
            return not gates
        if t == "B_GATE":
            return gates
        return False

    def bo(x, y, dv):
        dd = ONEWAY_DIR.get(ter[y][x])
        return dd is not None and dv != DIRV[dd]

    if not (0 <= p1[0] < GRID_W and 0 <= p1[1] < GRID_H):
        return p0, 0, False, [p0], False
    if hw(p1[0], p1[1]) or occ[p1[1]][p1[0]] == "TNT" or occ[p1[1]][p1[0]] == "BOX":
        return p0, 0, False, [p0], False
    if bo(p1[0], p1[1], (dx, dy)):
        return p0, 0, False, [p0], False
    cur = p1
    dmg = 0
    flip = False
    dv = (dx, dy)
    steps = 0
    stop = False
    while True:
        steps += 1
        t = ter[cur[1]][cur[0]]
        if t == "PIT":
            dmg += 100
            stop = True
        elif t == "MIMIC":
            dmg += 45
            stop = True
        elif t == "HEAL":
            dmg -= 30
        elif t == "SWITCH":
            flip = not flip
        if steps >= 32 or stop:
            break
        nxt = None
        nd = dv
        if t == "ICE":
            nx, ny = cur[0] + dv[0], cur[1] + dv[1]
            if not (0 <= nx < GRID_W and 0 <= ny < GRID_H) or hw(nx, ny) or occ[ny][nx] in ("BOX", "TNT") or bo(nx, ny, dv):
                nxt = None
            else:
                nxt = (nx, ny)
        elif t in MIRROR_FOLD:
            nd = DIRV[MIRROR_FOLD[t][DIR_OF[dv]]]
            nx, ny = cur[0] + nd[0], cur[1] + nd[1]
            if not (0 <= nx < GRID_W and 0 <= ny < GRID_H) or hw(nx, ny) or occ[ny][nx] in ("BOX", "TNT") or bo(nx, ny, nd):
                nxt = None
            else:
                nxt = (nx, ny)
        elif t in SPRING_DIR:
            sd = DIRV[SPRING_DIR[t]]
            nd = sd
            land = (cur[0] + 3 * sd[0], cur[1] + 3 * sd[1])
            if not (0 <= land[0] < GRID_W and 0 <= land[1] < GRID_H):
                land = None
            for k in (1, 2, 3):
                px, py = cur[0] + k * sd[0], cur[1] + k * sd[1]
                blocked = (not (0 <= px < GRID_W and 0 <= py < GRID_H)) or hw(px, py) or \
                    occ[py][px] in ("BOX", "TNT") or bo(px, py, sd)
                if blocked:
                    land = (cur[0] + (k - 1) * sd[0], cur[1] + (k - 1) * sd[1]) if k >= 2 else None
                    break
            nxt = land
        if nxt is None:
            break
        cur = nxt
        dv = nd
        ex.append(cur)
    return cur, dmg, flip, ex, any(c != p0 for c in ex)


def _plan_reach(world, start, goal_set, deadline, hp=None, keys=None,
                allow_turns=None, weight_dmg=3.0):
    """时间展开 A*：在 (cell, gates, phase, hp 桶) 上求最短代价动作序列。"""
    ter = world.ter
    occ = world.occ
    hx, hy, hhp, k1, k2, jumps, throws, bombs = world.hero
    if hp is None:
        hp = hhp
    if keys is None:
        keys = (k1, k2)
    gates0 = world.gates
    phase0 = world.turn % 12
    goal_set = set(goal_set)
    if not goal_set:
        return None
    dist = {}
    prev = {}
    start_state = (start, gates0, phase0, hp // 10)
    dist[start_state] = 0.0
    pq = [(0.0, start_state)]
    node_cap = 90000
    expanded = 0
    found = None
    while pq:
        d, st = heapq.heappop(pq)
        if d > dist.get(st, 1e18) + 1e-9:
            continue
        cell, gates, phase, hpb = st
        if cell in goal_set:
            found = st
            break
        expanded += 1
        if expanded > node_cap:
            break
        if (expanded & 1023) == 0 and time.monotonic() > deadline:
            break
        cx, cy = cell % GRID_W, cell // GRID_W
        for dk in DIR_KEYS:
            end, dmg, flip, ex, moved = _sim_hero_move(ter, occ, gates, cx, cy, dk)
            if not moved:
                continue
            nphase = (phase + 1) % 12
            hit = 0
            if nphase % 3 == 0 or nphase % 4 == 0:
                for (ex_, ey_) in ex:
                    hit |= world.hazard[ey_][ex_]
                m = bin(hit & (1 << (nphase if nphase else 12))).count("1") if False else 0
                # 逐门计数：hazard 只记录是否有激光，这里用 50 点估计
                has = (hit >> (nphase if nphase else 12)) & 1
                if has:
                    m = 1
            else:
                m = 0
            tot_dmg = dmg + 50 * m
            nhp = hp - dmg
            if nhp <= 0:
                continue
            ncell = end[1] * GRID_W + end[0]
            ngates = (not gates) if flip else gates
            cost = d + 1.0 + weight_dmg * (dmg + 50 * m)
            nst = (ncell, ngates, nphase, max(0, nhp) // 10)
            if cost < dist.get(nst, 1e18) - 1e-9:
                dist[nst] = cost
                prev[nst] = (st, MOVE_ACT[dk])
                heapq.heappush(pq, (cost, nst))
        # WAIT
        nphase = (phase + 1) % 12
        hit = world.hazard[cy][cx]
        m = 1 if (nphase % 3 == 0 or nphase % 4 == 0) and ((hit >> (nphase if nphase else 12)) & 1) else 0
        cost = d + 1.0 + weight_dmg * 50 * m
        nst = (cell, gates, nphase, hp // 10)
        if hp - 50 * m > 0 and cost < dist.get(nst, 1e18) - 1e-9:
            dist[nst] = cost
            prev[nst] = (st, "WAIT")
            heapq.heappush(pq, (cost, nst))
    if found is None:
        return None
    acts = []
    st = found
    while st in prev:
        pst, act = prev[st]
        acts.append(act)
        st = pst
    acts.reverse()
    return acts


def _goal_cells(world, name):
    t = world.targets.get(name)
    if t:
        return [int(t[1]) * GRID_W + int(t[0])]
    out = []
    for y in range(GRID_H):
        for x in range(GRID_W):
            if world.ter[y][x] == name:
                out.append(y * GRID_W + x)
    return out
