
INF = 1_000_000
DOUBLE = tuple(tuple(_neighbor(p,d,2) for d in range(4)) for p in range(SIZE))
MOMENTUM = {ICE, *range(MNE, SR + 1), *range(P1A, P2B + 1)}


def _from_state(state):
    terrain = [CODE[t] for row in state["terrain"] for t in row]
    clues = [c for row in state["clues"] for c in row]
    for p, t in enumerate(terrain):
        if t == CHEST:
            terrain[p] = MIMIC if any(q >= 0 and clues[q] for q in NEIGHBORS[p]) else HEAL
    occ = [BOX if o == "BOX" else TNT if o == "TNT" else 0
           for row in state["occupant"] for o in row]
    return _World(terrain, occ, state["hero"], state["gates_flipped"], state["bombs"])


def _snapshot(w):
    # Compare the actual observation with the exact predicted next state.
    return hash((tuple(w.tile(p) for p in range(SIZE)), tuple(w.occ(p) for p in range(SIZE)),
                 w.p, w.hp, w.keys, w.flipped, w.jumps, w.throws, w.stock,
                 tuple(sorted(w.bombs))))


def _relaxed_world(root, open_plate, demolition, fill):
    tiles = [root.tile(p) for p in range(SIZE)]
    costs = [0] * SIZE
    for p, t in enumerate(tiles):
        if t in (RED, BLUE) or (t == PGATE and open_plate):
            tiles[p] = EMPTY
            costs[p] = 0 if not root.high(p) else 2
        elif demolition and (t == WALL or _laser(t)):
            tiles[p] = EMPTY
            costs[p] = 8 if t == WALL else 10
        elif t == PIT and fill:
            tiles[p] = EMPTY
            costs[p] = 16
        elif t == MIMIC:
            costs[p] = 3 if root.throws else 18
        if root.occ(p) == TNT:
            costs[p] += 5
    fake = _World(tiles, [0] * SIZE, dict(x=0,y=0))
    return fake, costs


class _Graph:
    """Reverse navigation graph with exact static momentum and priced relaxations."""

    def __init__(self, root, open_plate=True, demolition=True, fill=False):
        model, costs = _relaxed_world(root, open_plate, demolition, fill)
        self.reverse = [[] for _ in range(SIZE)]
        self.fields = {}
        for p in range(41, 999):
            if model.high(p) or model.tile(p) == PIT:
                continue
            for d, q in enumerate(NEIGHBORS[p]):
                if model.high(q) or _against(model.tile(q), d):
                    continue
                for dest, jump in ((q, 0), (DOUBLE[p][d], 1)):
                    t = model.tile(dest)
                    if (model.high(dest) or t == PIT or _against(t, d)
                            or (jump and (not root.jumps or costs[q] >= 8 and root.tile(q) != PIT))):
                        continue
                    land = dest
                    if t in MOMENTUM:
                        w = model.clone()
                        w.p, w.exposed = p, {p}
                        w.displace(p, dest, d)
                        if w.hp <= 0:
                            continue
                        land = w.p
                    if land != p:
                        weight = 1 + costs[dest] + (0.9 if jump else 0)
                        self.reverse[land].append((p, weight))
        # Being on a gate when it closes allows departure under the exact model.

    def distances(self, target):
        if target in self.fields:
            return self.fields[target]
        dist = [INF] * SIZE
        dist[target] = 0
        queue = [(0, target)]
        while queue:
            n, p = heapq.heappop(queue)
            if n != dist[p]:
                continue
            for q, c in self.reverse[p]:
                v = n + c
                if v < dist[q]:
                    dist[q] = v
                    heapq.heappush(queue, (v, q))
        self.fields[target] = dist
        return dist


class _PushGuide:
    """Reverse box-push distances. Exact search resolves hero access and other boxes."""

    def __init__(self, root, graph):
        self.root, self.graph = root, graph
        model, ignored = _relaxed_world(root, root.active, False, False)
        self.reverse = [[] for _ in range(SIZE)]
        self.out = [[] for _ in range(SIZE)]
        for p in range(41, 999):
            if model.high(p) or model.tile(p) in (PIT, K1, K2, VAULT):
                continue
            for d, q in enumerate(NEIGHBORS[p]):
                stand = NEIGHBORS[p][d ^ 1]
                if (model.high(stand) or model.tile(stand) == PIT or
                        _against(model.tile(p), d) or model.high(q) or
                        _against(model.tile(q), d) or model.tile(q) in (K1, K2, VAULT)):
                    continue
                land = q
                if model.tile(q) in MOMENTUM:
                    w = model.clone()
                    w.p = stand
                    w.set_occ(p, BOX)
                    w.displace(p, q, d, True)
                    if w.boxes:
                        land = next(iter(w.boxes))
                    else:
                        land = next((r for r, val in w.t.items() if
                                     val == EMPTY and model.tile(r) == PIT), q)
                if land != p:
                    self.reverse[land].append(p)
                    self.out[p].append((land, stand))
        self.fields = {}

    def distances(self, target):
        if target not in self.fields:
            dist = [INF] * SIZE
            dist[target] = 0
            queue = collections.deque([target])
            while queue:
                p = queue.popleft()
                for q in self.reverse[p]:
                    if dist[q] == INF:
                        dist[q] = dist[p] + 1
                        queue.append(q)
            self.fields[target] = dist
        return self.fields[target]

    def estimate(self, w, target):
        dist = self.distances(target)
        best = INF
        pinned = set(w.plates) & w.boxes
        for b in w.boxes:
            if b in pinned or dist[b] == INF:
                continue
            for land, stand in self.out[b]:
                if dist[land] >= dist[b]:
                    continue
                walk = self.graph.distances(stand)[w.p] if stand in self.graph.fields else _manhattan(w.p, stand)
                best = min(best, 2.8 * dist[b] + min(walk, _manhattan(w.p,stand) + 24))
        return best


def _task(root, targets, memory, graph, guide, kind):
    positions = targets
    def make(goal, fn, progress):
        return goal, fn, progress

    if kind == "plates":
        choices = [p for p in root.plates if p not in root.boxes]
        if choices:
            # Prefer an assignment that leaves a distinct viable box for each other plate.
            def assignment(p, remaining, used):
                if not p:
                    return 0
                ds = guide.distances(p[0])
                return min((ds[b] + assignment(p[1:], remaining, used | {b})
                            for b in remaining if b not in used and ds[b] < INF),
                           default=INF)
            candidates = []
            available = root.boxes - set(root.plates)
            for p in choices:
                ds = guide.distances(p)
                reserve = min((ds[b] + assignment([q for q in choices if q != p], available, {b})
                               for b in available if ds[b] < INF), default=INF)
                candidates.append((guide.estimate(root,p) + min(reserve,1000) * .7, p))
            candidates.sort()
            options = [p for score,p in candidates if score < INF]
            if options:
                p = options[memory.get("preference", 0) % len(options)]
                # Path costs to the initial push fronts prevent wall-side oscillations.
                for b in root.boxes:
                    for dest, stand in guide.out[b]:
                        if guide.distances(p)[dest] < guide.distances(p)[b]:
                            graph.distances(stand)
                return make(lambda w: p in w.boxes,
                            lambda w: 0 if p in w.boxes else guide.estimate(w,p),
                            lambda w: sum(q in w.boxes for q in w.plates))
    if kind == "bridge":
        pits = [p for p in range(SIZE) if root.tile(p) == PIT and any(
            guide.distances(p)[b] < INF for b in root.boxes - set(root.plates))]
        if pits:
            # Rank by route savings after filling, favor bridge points directly
            # paired with another pit or a one-way barrier.
            reachable = _Graph(root, open_plate=True, demolition=bool(root.stock), fill=False)
            fields = [reachable.distances(p) for p in positions]
            desired = [i for i in range(2) if not root.keys & (1 << i)] or [2]
            def priority(p):
                neighbors = [q for q in NEIGHBORS[p] if q >= 0 and not root.high(q)]
                separation = any(min(fields[i][q] for q in neighbors) < INF and
                                 max(fields[i][q] for q in neighbors) == INF for i in desired) if neighbors else False
                obstacle = any(root.tile(q) == PIT or OU <= root.tile(q) <= OR for q in neighbors)
                return guide.estimate(root,p) + min(_manhattan(p,positions[i]) for i in desired) * .8 - 11*separation - 5*obstacle
            pits.sort(key=priority)
            p = pits[memory.get("preference", 0) % len(pits)]
            return make(lambda w: w.tile(p) != PIT,
                        lambda w: 0 if w.tile(p) != PIT else guide.estimate(w,p),
                        lambda w: 0)

    f1, f2, fv = [graph.distances(p) for p in positions]
    def all_keys(w):
        p=w.p
        if w.keys == 3:
            return fv[p]
        if w.keys == 1:
            return f2[p] + fv[positions[1]]
        if w.keys == 2:
            return f1[p] + fv[positions[0]]
        return min(f1[p] + f2[positions[0]] + fv[positions[1]],
                   f2[p] + f1[positions[1]] + fv[positions[0]])
    def estimate(w):
        n=all_keys(w)
        if n < INF:
            return n
        pending = [positions[i] for i in range(2) if not w.keys & (1 << i)] or [positions[2]]
        return 135 + min(_manhattan(w.p,p) for p in pending) + 35*(2-w.keys.bit_count())
    return make(lambda w: w.won, estimate, lambda w: w.keys.bit_count())


def _actions(w, expanded, jumps_free):
    for d,q in enumerate(NEIGHBORS[w.p]):
        t = w.tile(q)
        if w.high(q) or _against(t,d):
            continue
        if t != PIT and w.occ(q) != TNT:
            yield MOVES[d]
        if w.jumps:
            r = DOUBLE[w.p][d]
            if (jumps_free or t in (PIT, MIMIC, CRACK, SWITCH) or t in MOMENTUM
                    or w.tile(r) in MOMENTUM or w.occ(q) or w.bombs or w.lasers
                    or w.tile(r) in (K1,K2,VAULT,SWITCH,HEAL)):
                if w.tile(r) != PIT and not w.blocked(r,d):
                    yield JUMPS[d]
    if w.throws and w.interactive:
        yield from THROWS
    if w.stock and not any(p == w.p for p,t in w.bombs):
        if any(w.tile(q) in (WALL,RED,BLUE) or _laser(w.tile(q)) or w.occ(q) for q in BLAST[w.p]):
            yield "BOMB"
    if w.bombs or w.lasers:
        yield "WAIT"


def _plan(root, turn, objective, estimate, progress, deadline, memory, width):
    remaining = 241-turn
    queue = [(estimate(root), 0.0, 0, root, 0)]
    seen = {root.key(turn): 0.0}
    links = [(-1,"")]
    best_id, best, best_depth = 0, INF, 0
    best_progress = progress(root)
    expanded=0
    weights = (2.35, 3.8, 1.3, 5.2)
    weight = weights[memory.get("attempt",0) % len(weights)]
    visits = memory.get("visits", {})
    pinned = set(root.plates) & root.boxes
    root_h = estimate(root)
    while queue and expanded < width:
        if expanded % 16 == 0 and time.monotonic() >= deadline:
            break
        _, cost, node, w, depth = heapq.heappop(queue)
        if cost != seen.get(w.key(turn+depth)):
            continue
        if objective(w):
            best_id=node
            success=True
            break
        if node:
            made = progress(w)
            h = estimate(w)
            value = h + cost * .31 + (0.0 if not w.bombs else 4.0)
            if made > best_progress or (made == best_progress and
                                        (value < best or value == best and depth > best_depth)):
                best,best_id,best_depth,best_progress=value,node,depth,made
        if depth >= remaining:
            continue
        expanded += 1
        for action in _actions(w,expanded,memory.get("attempt",0)>0):
            child=w.step(action,turn+depth)
            if child.hp <= 0:
                continue
            same = (child.p == w.p and child.signature == w.signature and
                    child.flipped == w.flipped and child.bombs == w.bombs)
            if same and action != "WAIT":
                continue
            if action in THROWS and child.signature == w.signature and child.flipped == w.flipped:
                continue
            # Once a complete route is available, all inventory use on it is safe.
            # While searching, favor health and scarce resources over cosmetic shortcuts.
            step = 1 + max(0, w.hp-child.hp) * 1.95
            if child.hp > w.hp:
                step -= .70
            if child.stock < w.stock:
                step += 5.0
            if child.jumps < w.jumps:
                step += 1.6
            if child.throws < w.throws:
                step += 1.1
            if pinned and child.boxes != w.boxes:
                step += 12 * len((pinned & w.boxes) - child.boxes)
            if depth < 3:
                step += .52 * min(8, visits.get(str(child.p),0))
            new_cost = cost + step
            nd=depth+1
            key=child.key(turn+nd)
            if new_cost >= seen.get(key,INF):
                continue
            seen[key]=new_cost
            node2=len(links);links.append((node,action))
            h=0 if objective(child) else estimate(child)
            heapq.heappush(queue,(new_cost + weight*h,new_cost,node2,child,nd))
    else:
        success=False
    if not queue and not best_id:
        success=False
    if "success" not in (): # success is set by a goal pop or the final check below
        pass
    path=[]
    while best_id:
        best_id,action=links[best_id]
        path.append(action)
    path.reverse()
    # A deadline break can also land on an already simulated terminal state;
    # replay of the returned route decides whether it is ready to commit.
    return path, expanded, best, root_h


def _safe_action(root, turn, targets, memory):
    best, selected = -INF, "WAIT"
    goals = [p for i,p in enumerate(targets[:2]) if not root.keys & (1<<i)] or targets[2:]
    for action in ALL_ACTIONS:
        w = root.step(action,turn)
        if w.hp <= 0:
            continue
        score = (100000 if w.won else 0) + 260 * w.keys.bit_count() + 3 * w.hp
        score -= min(_manhattan(p,q) for p in w.exposed for q in goals)
        score -= 2.5 * memory.get("visits",{}).get(str(w.p),0)
        score -= 9*(root.stock-w.stock) + 4*(root.jumps-w.jumps) + 4*(root.throws-w.throws)
        if w.p == root.p and action != "WAIT":
            score -= 8
        if not w.won and turn < 240 and not any(
                w.step(a,turn+1).hp > 0 for a in (*MOVES,*JUMPS,"WAIT")):
            score -= 700
        if score > best:
            best, selected = score, action
    return selected


def _choose_plan(root, turn, targets, memory, deadline):
    graph = _Graph(root, demolition=bool(root.stock or root.throws))
    guided = bool(root.boxes)
    guide = _PushGuide(root,graph) if guided else None
    kind = "main"
    required_plate = False
    pending = [p for i,p in enumerate(targets[:2]) if not root.keys & (1<<i)] + [targets[2]]
    if guided and root.plates and not root.active and PGATE in root.base_t:
        closed = _Graph(root, open_plate=False, demolition=bool(root.stock or root.throws), fill=True)
        required_plate = any(closed.distances(p)[root.p] == INF for p in pending)
        if required_plate:
            kind = "plates"
    if guided and kind == "main" and any(graph.distances(p)[root.p] == INF for p in pending):
        kind = "bridge"
    if guided and memory.get("stalled",0) >= 9:
        memory["preference"] = memory.get("preference",0) + 1
        if root.plates and not root.active:
            kind="plates"
        elif memory["preference"] % 2:
            kind="bridge"
    goal, h, progress = _task(root,targets,memory,graph,guide,kind)
    path,n,best,h0=_plan(root,turn,goal,h,progress,deadline,memory,24000 if turn==1 else 8000)
    w=root
    for i,action in enumerate(path):
        w=w.step(action,turn+i)
    complete=bool(path) and goal(w) and (kind!="main" or w.won)
    if complete:
        memory["stalled"]=0
    else:
        memory["stalled"]=memory.get("stalled",0)+1
        memory["attempt"]=memory.get("attempt",0)+1
    memory["nodes"],memory["kind"],memory["complete"] = n,kind,complete
    # Commit proven stage plans. Partial searches are receding-horizon and
    # preserve enough of a promising path to cross flat heuristic plateaus.
    return path if complete or w.won else path[:(3 if best < h0+4 else 1)]


def decide_action(state, memory):
    started=time.monotonic()
    turn=state["turn"]
    root=_from_state(state)
    targets=tuple(state["targets"][name][1]*40+state["targets"][name][0] for name in ("K1","K2","V"))
    if turn==1:
        memory.clear()
    visits=memory.setdefault("visits",{})
    p=str(root.p)
    visits[p]=visits.get(p,0)+1
    cached=memory.get("plan",[])
    if cached and memory.get("expected")==_snapshot(root):
        route=cached
    elif turn==240:
        route=[]
    else:
        route=_choose_plan(root,turn,targets,memory,started+(1.54 if turn==1 else .36))
    action=route[0] if route else _safe_action(root,turn,targets,memory)
    after=root.step(action,turn)
    if after.hp <= 0:
        action=_safe_action(root,turn,targets,memory)
        after=root.step(action,turn)
        route=[]
    memory["plan"]=route[1:]
    memory["expected"]=_snapshot(after)
    return action
