import sys, importlib.util, json
sys.path.insert(0, r"part2_full_mode/exam_rooms\P2_11_doubao_vscode")
def load(name):
    spec = importlib.util.spec_from_file_location(name, r"part2_full_mode/exam_rooms\P2_11_doubao_vscode\\"+name)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
sub = load("submission.py")
d = sub.build_dungeon()
g = d["grid"]; sol = d["author_solution"]
GW=40; GH=26
cost = sum(sub.TILE_COSTS.get(t,0) for row in g for t in row)
# plates vs boxes count
plates=sum(1 for row in g for t in row if t=="PLATE")
boxes=sum(1 for row in g for t in row if t=="BOX")
print("cost=%d plates=%d boxes=%d sol_len=%d" % (cost, plates, boxes, len(sol)))
print("budget_ok=%s plate_ok=%s sol_len_ok=%s" % (cost<=2000, 1<=plates<=boxes, 1<=len(sol)<=200))
# simulate solution
w = sub.World(g)
ok=True; hp0=w.hero["hp"]
for i,a in enumerate(sol):
    w.step(a)
    if w.dead():
        ok=False; print("DIED at step",i+1,a); break
print("sim: cleared=%s end_pos=(%d,%d) hp=%d turn=%d alive=%s" % (w.cleared(), w.hero["x"], w.hero["y"], w.hero["hp"], w.turn, not w.dead()))
# birth-4-turn safety: count distinct Turn-1 zero-damage landing spots that survive to T4 with zero mechanic damage
def safe_after(w, turn):
    return not w.dead() and w.turn<=turn
from copy import deepcopy
safe_spots=set()
# turn1 actions that result in zero damage and position; then WAIT to T4 checking damage
for a1 in ("MOVE_R","MOVE_D","MOVE_L","MOVE_U","WAIT"):
    ww = sub.World(g)
    hp_before=ww.hero["hp"]
    ww.step(a1)
    if ww.dead() or ww.hero["hp"]<hp_before: continue
    spot=(ww.hero["x"],ww.hero["y"])
    # continue to turn4 with zero damage
    cur=spot; bad=False
    w2=sub.World(g); w2.step(a1)
    for _ in range(3):
        hpb=w2.hero["hp"]; w2.step("WAIT")
        if w2.dead() or w2.hero["hp"]<hpb: bad=True; break
    if not bad and not w2.dead():
        safe_spots.add(spot)
print("birth-safe spots (T1 zero-dmg + survive to T4):", len(safe_spots), sorted(safe_spots))
print("ADMIT_OK=", len(safe_spots)>=2 and ok and w.cleared())
