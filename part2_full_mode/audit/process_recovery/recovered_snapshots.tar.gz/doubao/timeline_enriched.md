# 豆包 (`P2_11_doubao_vscode`) 完整日志补全复盘

从 Trae 客户端终端执行日志 [203414-393-39404-vscode-2026-11-19-39404.log](file:///<LOCAL_USER_HOME>/.marscode/logs/2026-11-19/clients/203414-393-39404-vscode-2026-11-19-39404.log) 提取出全晚 `110` 次终端工具命令，将其中的 `submission.py` 补丁依次在临时目录重放（以 `02_line3890_submission.py` 为基座），最终重放产物 SHA-256 前缀 **`9f951f4a`**（`37,431B`）与考场最终原件 **100% 逐字节一致**。

提取命令目录：[recovered_cmds](file:///part2_full_mode/audit/process_recovery_20261119/doubao/recovered_cmds) · 重放快照目录：[recovered_from_cmds](file:///part2_full_mode/audit/process_recovery_20261119/doubao/recovered_from_cmds)

## 补全后完整时间线（2026-11-19 JST，起点 `20:37:29`）

1. **20:37:29–21:11（搭建本地 `_engine.py` 并校对规则）**
   - 先读 `submission_template_v22.py` 与旧 `submission.py`，`20:47:18` 写出本地前向模拟器 `_engine.py` 并对着 `golden_vectors` 和边界条件连续打补丁（`20:54–21:03`）。
2. **21:12:51（35 分 22 秒，`L1385`）→ 实际 40:00 卡点版本**
   - 写入首份完整 `submission.py`（`23,113B`，已含两处 `__new__`）。
   - `21:17:12`（`39 分 43 秒`，仅距 `21:17:29` 的 40 分钟界限 17 秒，`L1581`）修改的只是测试脚本 `_solve_bench.py`，因此 **`01_line1385_submission.py` 就是 40:00 截稿瞬间的磁盘原件**。
3. **21:30:18–21:51:19（52 分 49 秒–73 分 50 秒，两轮重写加速）**
   - `21:30:18`（`L3890`）整体重写 `submission.py` 到 `28,398B`；
   - `21:32:30–21:35:03`（`L4030/4110/4160`）加入 `_scan_features()`、优化 `pa()` 与 `laser_beams` 并修 `_tnt_present`（`febd6b8e`，`30,314B`）；
   - `21:51:19`（`L4854`）在 `clone()` 中改为共享地形、元组化 `_boxes` 并重写 `search()`/`decide_action()`（`197a37d6`，`35,519B`）。
4. **22:08:17（`L6548`，开考 91 分钟）→ 外墙 `W` 违规写入点**
   - 整体重写 `search + decide_action + build_dungeon()`（`0c4f15a7`，`36,201B`）。
   - 该段源码里把主地图及两套兜底地图的四条外圈边框全部硬编码为普通墙 `"W"`（`grid[0][x] = "W"` 等），直接违背“最外圈必须为 `T_W`”铁律，导致重测时魔王席被替换为备用图且记 `0` 分。
5. **22:12:49–22:22:02（加压板启发函数 → 10 分钟后回滚）**
   - `22:12:49`（`L6894`）新增 `_plate_penalty()` 与 `_reachable()`（`a981d7b1`，`37,616B`）；
   - `22:22:02`（`L8068`）整段撤回新版 `heuristic`，恢复旧版 `ORIG_HEUR` 并收紧续跑阈值（`d46227eb`，`36,988B`）。
6. **22:24:10–22:32:41（自测盲区 + 末段收紧预算）**
   - `22:24:10`（`L8546`）跑的 AST 自检只扫描了 `Import` / `ImportFrom`；`22:25:19`（`L8587`）写出的 `_final_check.py` 直接 `importlib` 普通导入，未经过官方沙盒 AST 前缀拦截与外圈 `T_W` 校验。
   - `22:29:46`（`L9126`）写入 `hard = 1.8 / 0.40 + stagnation guard`（`372a896b`）；
   - `22:32:18`（`L9611`）最终把时间硬上限进一步收紧到 `hard = 1.7 / 0.35`（`9f951f4a`，`37,431B`）。

## 仍缺失（Trae 本地锁在加密库中，需界面导出或人工补充）

- 会话气泡中的**助手回复文字与思考理由**、`20:37–22:34` 这轮会话的**精确 Token / 用量统计**（`<LOCAL_USER_HOME>\.marscode\ai-chat\AppData\vscode\ai-agent\database.db` 为非明文专有数据库），以及 `22:34:20` 最后工具调用后为何终止（正常答复收尾或人工叫停）。
